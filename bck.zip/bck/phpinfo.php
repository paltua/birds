<?php 
echo phpinfo();

?>